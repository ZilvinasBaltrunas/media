'use strict'

// NAV LIST
let navList = ["kotedžai", "gyvenimas slėnyje", "galerija", "gyventojams", "naujienos", "kontaktai"];
function navigation () {
    for (let i=0; i<navList.length; i++) {
        let liElement = document.createElement("LI");
        let aElement = document.createElement("A");
        aElement.href = "#";
        let text = document.createTextNode(navList[i]);
        liElement.appendChild(aElement);
        aElement.appendChild(text);
        document.getElementById("list").appendChild(liElement);
    }
}
navigation();

// OVER / ACTIVE
let allButtons = document.getElementById("info__header").getElementsByClassName("box");
for (let i = 0; i<allButtons.length; i++) {
    allButtons[i].addEventListener("click", function() {
        let current = document.getElementsByClassName("active");
        current[0].className = current[0].className.replace(" active", "");
        this.className += " active";
    });
}

// FORM VALIDATION
document.getElementById("button").addEventListener("click", function() {
    console.log('fff');
    let email = document.getElementById("email");
    let phone = document.getElementById("phone");
    let time = document.getElementById("time");
    if (email.value == '' &&
        phone.value == '' &&
        time.value == ''
    ) {
        alert('please, fill all form lines');
    } else
    if (email.value.length > 25 ||
        phone.value.length > 12 ||
        time.value.length > 25
    ) {
        alert('filled information lines are too long');
    }
});